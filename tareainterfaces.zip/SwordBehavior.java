public class SwordBehavior implements  WeaponBehavior{
  //sobre escribir el metodo fly
public void fight (){
  System.out.println ("I´m using a Sword");
}
  
}