public class Knight extends Character {

  public Knight (){
    fb = new SwordBehavior();
  }

  public void display (){
    System.out.println ("I´m a Knight");
  }
  
}