public class King extends Character {

  public King (){
    fb = new KnifeBehavior ();
  }

  public void display (){
    System.out.println ("I´m a King");
  }
  
}