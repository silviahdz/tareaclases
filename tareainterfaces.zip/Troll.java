public class Troll extends Character {

  public Troll (){
    fb = new BowAndArrowBehavior ();
  }

  public void display (){
    System.out.println ("I´m a Troll");
  }
  
}