class Main {
  public static void main(String[] args) {
    System.out.println("Accion");

    //Código para mostrar los 5 tipos de patos con el metodo showDuck

    Character king, queen, troll, knight;

    king    = new King  ();
    queen = new Queen  ();
    troll  = new Troll ();
    knight = new Knight ();
    

    //Esto debe llamar todos los println y mostrar lo uqe hace el pato
    troll.setWeaponBehavior(new BowAndArrowBehavior());
     king.setWeaponBehavior(new KnifeBehavior());
     queen.setWeaponBehavior(new AxeBehavior());
     knight.setWeaponBehavior(new SwordBehavior());
    king.showCharacter();
    queen.showCharacter();
    troll.showCharacter();
    knight.showCharacter();
    

    
    
    
  }
}