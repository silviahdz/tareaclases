public abstract class Character {

  WeaponBehavior fb;

  public abstract void display ();

  public void performWeapon (){
    fb.fight();
  }

  


  public void showCharacter (){
    display();
    
    performWeapon();
  }

  public void setWeaponBehavior (WeaponBehavior f){
    fb=f;
    
  }

  

  
}
