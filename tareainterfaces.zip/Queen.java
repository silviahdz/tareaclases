public class Queen extends Character {

  public Queen (){
    fb = new AxeBehavior ();
  }

  public void display (){
    System.out.println ("I´m a Queen");
  }
  
}