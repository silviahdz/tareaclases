public interface WeaponBehavior {

  //metodo abstracto
  public void fight ();
}